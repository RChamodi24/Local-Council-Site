<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $contactNumber = $_POST["contactNumber"];
    $subject = $_POST["subject"];
    $inquiryType = $_POST["inquiryType"];
    $message = $_POST["message"];

    // Email address to send the inquiry
    $to = "info@colombo.com";

    // Email subject
    $emailSubject = "New Inquiry: " . $subject;

    // Email content
    $emailContent = "Name: $name\n";
    $emailContent .= "Email: $email\n";
    $emailContent .= "Contact Number: $contactNumber\n";
    $emailContent .= "Inquiry Type: $inquiryType\n";
    $emailContent .= "Message: $message\n";

    // Send email
    if (mail($to, $emailSubject, $emailContent)) {
        echo "<script>alert('Your inquiry has been submitted successfully. We will get back to you soon.');</script>";
    } else {
        echo "<script>alert('Failed to submit inquiry. Please try again later.');</script>";
    }
}
?>